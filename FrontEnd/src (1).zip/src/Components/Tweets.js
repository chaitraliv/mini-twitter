import React, { Component } from 'react'

export class Tweets extends Component {
    render() {
        return (
            <div>
                
            </div>
        )
    }
}

export default Tweets
